import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, roc_curve, roc_auc_score, accuracy_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.svm import SVC
from sklearn.decomposition import PCA
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

class PyTorchMLP(nn.Module):
    def __init__(self, input_size, hidden_size=16):
        super(PyTorchMLP, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, 1)
    
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = torch.sigmoid(self.fc2(x))
        return x

def plot_roc_curve(y_true, y_scores, title='ROC Curve'):
    fpr, tpr, _ = roc_curve(y_true, y_scores)
    roc_auc = roc_auc_score(y_true, y_scores)
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (area = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.05])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(title)
    plt.legend(loc="lower right")
    plt.show()

def evaluate_models_pytorch(datasets):
    for name, X, y in datasets:
        print(f"\nEvaluating dataset: {name}")
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Convert to PyTorch tensors
        X_train_torch = torch.FloatTensor(X_train)
        X_test_torch = torch.FloatTensor(X_test)
        y_train_torch = torch.FloatTensor(y_train).view(-1, 1)
        y_test_torch = torch.FloatTensor(y_test).view(-1, 1)

        # SVM Evaluation
        svm_model = SVC(kernel='linear', probability=True)
        svm_model.fit(X_train, y_train)
        svm_predictions = svm_model.predict(X_test)
        print("SVM Confusion Matrix:\n", confusion_matrix(y_test, svm_predictions))
        svm_scores = svm_model.decision_function(X_test)
        plot_roc_curve(y_test, svm_scores, title=f'SVM ROC Curve for {name}')

        # PyTorch MLP Evaluation
        model = PyTorchMLP(input_size=X_train.shape[1])
        criterion = nn.BCELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001)

        # Train model
        model.train()
        for epoch in range(100):
            optimizer.zero_grad()
            outputs = model(X_train_torch)
            loss = criterion(outputs, y_train_torch)
            loss.backward()
            optimizer.step()

        # Evaluate model
        model.eval()
        with torch.no_grad():
            y_pred_proba = model(X_test_torch)
            y_pred = (y_pred_proba >= 0.5).float()
            accuracy = accuracy_score(y_test, y_pred.numpy())
            print(f"PyTorch MLP Accuracy: {accuracy:.2f}")

        # PCA Visualization for datasets with more than 2 features
        if X.shape[1] > 2:
            pca = PCA(n_components=2)
            X_pca = pca.fit_transform(X)
            plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y, cmap='viridis', alpha=0.5)
            plt.title(f'{name} Data Visualization with PCA')
            plt.xlabel('Principal Component 1')
            plt.ylabel('Principal Component 2')
            plt.colorbar()
            plt.show()

# Loading and preprocessing datasets

# Load ring datasets
separable_data = np.loadtxt('A2-ring-separable.txt')
merged_data = np.loadtxt('A2-ring-merged.txt')
test_data = np.loadtxt('A2-ring-test.txt')

# Preprocess and scale ring datasets
scaler_ring = StandardScaler()
X_sep_scaled = scaler_ring.fit_transform(separable_data[:, :2])
y_sep = separable_data[:, 2]
X_merged_scaled = scaler_ring.fit_transform(merged_data[:, :2])
y_merged = merged_data[:, 2]
X_test_scaled = scaler_ring.fit_transform(test_data[:, :2])
y_test = test_data[:, 2]

data_gender = pd.read_csv('A2-gender.txt', delimiter='\t', header=None, names=['longhair', 'foreheadwidthcm', 'foreheadheightcm', 'nosewide', 'noselong', 'lipsthin', 'distancenosetoliplong', 'gender'])

# Convert all columns to numeric, coercing errors to NaN (adjust as necessary for your dataset)
for col in data_gender.columns[:-1]:  # Assuming the last column 'gender' is categorical
    data_gender[col] = pd.to_numeric(data_gender[col], errors='coerce')

# Drop any rows with NaN values that resulted from errors in conversion
data_gender.dropna(inplace=True)

# Encode the 'gender' column if it's categorical
data_gender['gender'] = LabelEncoder().fit_transform(data_gender['gender'])

# Now, separate features and labels
X_gender = data_gender.iloc[:, :-1].values
y_gender = data_gender['gender'].values

# Proceed with scaling as before
scaler_gender = StandardScaler()
X_gender_scaled = scaler_gender.fit_transform(X_gender)

# Preprocess and scale bank dataset
data_bank = pd.read_csv('bank-additional.csv', delimiter=';')
data_bank['y'] = LabelEncoder().fit_transform(data_bank['y'])
data_bank = pd.get_dummies(data_bank, drop_first=True)
scaler_bank = StandardScaler()
X_bank_scaled = scaler_bank.fit_transform(data_bank.drop('y', axis=1))
y_bank = data_bank['y'].values

# Define datasets list
datasets = [
    ("Separable", X_sep_scaled, y_sep),
    ("Merged", X_merged_scaled, y_merged),
    ("Test", X_test_scaled, y_test),
    ("Gender", X_gender_scaled, y_gender),
    ("Bank", X_bank_scaled, y_bank)
]

evaluate_models_pytorch(datasets)
