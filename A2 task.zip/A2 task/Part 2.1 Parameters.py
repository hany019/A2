import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV, train_test_split, KFold, cross_val_score
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import torch
import torch.nn as nn
import torch.optim as optim

# Define a custom neural network class using PyTorch for MLP
class Net(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        x = self.sigmoid(x)
        return x

# Function to perform cross-validation for neural network
def cross_validate_nn(X, y, param_grid, num_folds=5):
    best_val_error = float('inf')
    best_params = None
    kf = KFold(n_splits=num_folds, shuffle=True, random_state=42)
    
    for train_index, val_index in kf.split(X):
        X_train, X_val = X[train_index], X[val_index]
        y_train, y_val = y[train_index], y[val_index]
        
        for params in param_grid:
            net = Net(input_size=X_train.shape[1], hidden_size=params['neurons'])
            criterion = nn.BCELoss()
            optimizer = optim.Adam(net.parameters(), lr=0.001)
            for epoch in range(params['epochs']):
                # Train the model on training data
                net.train()
                optimizer.zero_grad()
                outputs = net(torch.FloatTensor(X_train))
                loss = criterion(outputs, torch.FloatTensor(y_train).view(-1, 1))
                loss.backward()
                optimizer.step()

            # Evaluate the model on validation data
            net.eval()
            with torch.no_grad():
                val_outputs = net(torch.FloatTensor(X_val))
                val_predictions = (val_outputs >= 0.5).float()
                correct = (val_predictions.view(-1) == torch.FloatTensor(y_val)).float().sum()
                val_error = 1 - correct / len(y_val)
                
                if val_error < best_val_error:
                    best_val_error = val_error
                    best_params = params
                    
    return best_params, best_val_error.item()

# Load and preprocess datasets
# Ring datasets
separable_data = np.loadtxt('A2-ring-separable.txt')
merged_data = np.loadtxt('A2-ring-merged.txt')
test_data = np.loadtxt('A2-ring-test.txt')

# Bank dataset
data = pd.read_csv('bank-additional.csv', delimiter=';')
# Assuming preprocessing is done here for the 'Bank' dataset

datasets = [
    ("Sep", separable_data[:, :-1], separable_data[:, -1]),
    ("Merged", merged_data[:, :-1], merged_data[:, -1]),
    # Include any other datasets you are using
]

# Define parameter grid for neural network
nn_param_grid = [
    {'neurons': 16, 'epochs': 10},
    {'neurons': 32, 'epochs': 20},
    # Add more parameter combinations as needed
]

for name, X, y in datasets:
    print(f"Working on dataset: {name}")

    # Normalize features
    scaler = StandardScaler()
    X = scaler.fit_transform(X)
    
    # Split data into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # SVM Parameter Selection with Cross-validation
    param_grid_svm = {
        'C': [0.1, 1, 10],
        'gamma': [0.001, 0.01, 0.1],
        'kernel': ['rbf', 'linear']
    }

    grid_search_svm = GridSearchCV(SVC(), param_grid_svm, cv=5)
    grid_search_svm.fit(X_train, y_train)

    best_svm = grid_search_svm.best_estimator_
    best_params_svm = grid_search_svm.best_params_
    cv_error_svm = 1 - grid_search_svm.best_score_
    svm_test_error = 1 - best_svm.score(X_test, y_test)

    print(f"SVM Best Params for {name}: {best_params_svm}")
    print(f"SVM Cross-validation Error for {name}: {cv_error_svm}")
    print(f"SVM Test Classification Error for {name}: {svm_test_error}")

    # MLP
    # MLP Parameter Selection with Cross-validation
    best_params_mlp, cv_error_mlp = cross_validate_nn(X_train, y_train, nn_param_grid)
    print(f"Best MLP Parameters for {name}: {best_params_mlp}")
    print(f"MLP Cross-validation Error for {name}: {cv_error_mlp}")

    # Evaluate the best MLP model on the test set
    best_mlp = Net(input_size=X_train.shape[1], hidden_size=best_params_mlp['neurons'])
    criterion = nn.BCELoss()
    optimizer = optim.Adam(best_mlp.parameters(), lr=0.001)
    
    # Train the model with the best parameters
    for epoch in range(best_params_mlp['epochs']):
        best_mlp.train()
        optimizer.zero_grad()
        outputs = best_mlp(torch.FloatTensor(X_train))
        loss = criterion(outputs, torch.FloatTensor(y_train).view(-1, 1))
        loss.backward()
        optimizer.step()
    
    # Evaluate the model on the test set
    best_mlp.eval()
    with torch.no_grad():
        test_outputs = best_mlp(torch.FloatTensor(X_test))
        test_predictions = (test_outputs >= 0.5).squeeze().numpy()
        mlp_test_error = 1 - np.mean(test_predictions == y_test)
    print(f"MLP Test Classification Error for {name}: {mlp_test_error}\n")

    # Logistic Regression for classification (MLR)
    lr_model = LogisticRegression(max_iter=1000, solver='lbfgs')
    lr_model.fit(X_train, y_train)
    lr_cv_scores = cross_val_score(lr_model, X_train, y_train, cv=5, scoring='accuracy')
    lr_cv_error = 1 - np.mean(lr_cv_scores)
    lr_test_score = lr_model.score(X_test, y_test)
    lr_test_error = 1 - lr_test_score
    print(f"Logistic Regression Cross-validation Accuracy for {name}: {np.mean(lr_cv_scores)}")
    print(f"Logistic Regression Cross-validation Error for {name}: {lr_cv_error}")
    print(f"Logistic Regression Test Accuracy for {name}: {lr_test_score}")
    print(f"Logistic Regression Test Error for {name}: {lr_test_error}\n")
